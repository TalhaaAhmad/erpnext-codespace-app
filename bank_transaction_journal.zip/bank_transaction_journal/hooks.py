doctype_js = {
    "Bank Transaction": "public/js/bank_transaction.js"
}
