# Bank Transaction Journal

ERPNext Custom App to create Journal Entries from Bank Transactions automatically.